﻿using Microsoft.CSharp.RuntimeBinder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using Task1OOP.Core;

namespace Task1OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //task1 - Complite

            //Address address = new Address();
            //address.Index = 456195;
            //address.Country = "Russia";
            //address.City = "Kimovsk";
            //address.Street = "Lenina";
            //address.House = "32A";
            //address.Apartment = 82;

            //Console.WriteLine($" Index - {address.Index}\n Country - {address.Country}\n City -{address.City}\n Street -{address.Street}\n House -{address.House}\n Apartament -{address.Apartment}\n");

            //task2
            //Rectangle rectangle = new Rectangle(33,1);

            //double Area = rectangle.Side1 * rectangle.Side2;
            //double Perimeter = (rectangle.Side1 + rectangle.Side2) * 2;

            //Console.WriteLine($" Area - {Area}\n Perimeter -{Perimeter}");

            //task3

            //Book book = new Book("Как не быть депрессивной?");
            //book.Show();

            //Title title = new Title("Глава1");
            //title.Show();

            //Author author = new Author("Мисс No Name");
            //author.Show();

            //Content content = new Content("Что-то из Дом2");
            //content.Show();



            //task4
            //Point point = new Point(22, 52, "nn");
            //Point point1 = new Point(23, 46, "nn");
            //Point point2 = new Point(25, 32, "nn");
            //Figure figure2 = new Figure(point, point1, point2);

            //task5
            //User user = new User();
            //user.Login = "lalala@la";
            //user.Name = "Kate";
            //user.Surname = "Suvorova";
            //user.Age = 25;
            //Console.WriteLine($" Login-{user.Login}\n Name-{user.Name}\n Surname-{user.Surname}\n Age-{user.Age}\n Date-{user._date}");

            //другие работы
            //task6
            //Converter converter = new Converter(1.3, 4.4, 3.5);
            //Console.Write("Курсы валют: ");
            //double rub = Convert.ToDouble(Console.ReadLine());
            //double btc = rub * converter.Btc;
            //double eth = rub * converter.Eth;
            //double bnb = rub * converter.Bnb;
            //Console.WriteLine($" Btc-{btc}\n Eth-{eth}\n Bnb-{bnb}\n");

            //Console.Write("Курс рубля: ");
            //double rub1 = Convert.ToDouble(Console.ReadLine());
            //double btc1 = rub / converter.Btc;
            //Console.WriteLine($" Btc-{btc1}\n ");

            //Console.Write("Курс рубля: ");
            //double rub2 = Convert.ToDouble(Console.ReadLine());
            //double eth2 = rub / converter.Eth;
            //Console.WriteLine($" Eth-{eth2}\n ");

            //Console.Write("Курс рубля: ");

            //double rub3 = Convert.ToDouble(Console.ReadLine());
            //double bnb3 = rub / converter.Bnb;

            //Console.WriteLine($" Bnb-{bnb3}\n");



            //task7
            //Employee employee = new Employee("Karol", "Nina");
            //employee.Dol = "инженер";
            //employee.Nalog = 13;
            //employee.Oclad = 25000;
            //employee.Doloclad = 30000;
            //employee.Rabd = 25;
            //employee.Fizrabd = 23;
            //double Nalog = employee.Oclad / employee.Nalog;
            //double Oclad = employee.Doloclad / employee.Rabd * employee.Fizrabd;
            //Console.WriteLine($" Фамилия-{employee.Surname}\n Имя-{employee.Name}\n Должность-{employee.Dol}\n Налог-{Nalog}\n Оклад-{Oclad}");

            //task8
            //Invoice invoice = new Invoice(34);
            //double Nds = 1000 * 0.3;
            //double Sumndc =Nds;
            //double Sumno=Sumndc+invoice.Stav;
            //Console.WriteLine($"Сумма без НДС-{Sumndc}\n Сумма с НДС-{Sumno}");


            //Thread.Sleep(10000);
        }

    }
}
