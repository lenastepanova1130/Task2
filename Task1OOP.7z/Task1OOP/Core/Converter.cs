﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Converter
    {
		private double _btc;

		public double Btc
		{
			get { return _btc; }
			set { _btc = value; }
		}

		private double _eth;

		public double Eth
		{
			get { return _eth; }
			set { _eth = value; }
		}

		private double _bnb;

		public Converter(double btc, double eth, double bnb)
		{
			Btc = btc;
			Eth = eth;
			Bnb = bnb;
		}

		public double Bnb
		{
			get { return _bnb; }
			set { _bnb = value; }
		}
       
	}
}
