﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Point
    {
		private int _num;

		public int Num
		{
			set { _num = value; }
			get { return _num; }
		}

		private int _num1;

		public int Num1
        {
			set {_num1 = value; }
			get { return _num1; }
		}


		private string _name;

		public string Name
        {
			set {_name= value; }
			get { return _name; }
		}
		public Point(int num, int num1, string name)
		{
			Num = num;			
			Num1 = num1;
			Name = name;
			
		}
	}
}
