﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Book
    {
		private string _book;

		public Book(string boo)
		{
			Boo = boo;
		}

		public string Boo
		{
			get { return _book; }
			set { _book = value; }
		}

		public void Show()
		{
			Console.ForegroundColor = ConsoleColor.DarkBlue;
			Console.WriteLine($"Книга -{Boo}");
			

		}
	}
}
