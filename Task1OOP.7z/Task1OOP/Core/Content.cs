﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Content
    {
        public Content(string cont)
        {
            Cont = cont;
        }

        private string _content;

		public string Cont
		{
			get { return _content; }
			set { _content = value; }
		}

        public void Show()
        {
            Console.ForegroundColor = ConsoleColor.Red; 
            Console.WriteLine($"Сюжет -{Cont}");
        }
    }
}
