﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Title
    {
        public Title(string tit)
        {
            Tit = tit;
        }

        private string _title;

		public string Tit
		{
			get { return _title; }
			set { _title = value; }
		}

        public void Show()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine($"Заголовок -{Tit}");
        }

    }
}
