﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Figure
    {
        //public Point MySide { get; set; }

        public Figure(Point point, Point point1, Point point2)
        {
            Perimeter(point);
            Perimeter(point1);
            Perimeter(point2);
        }

        public Figure(Point point, Point point1, Point point2, Point point3)
        {
          
        }

        public Figure(Point point, Point point1, Point point2, Point point3, Point point4)
        {
           
        }
        public double LengthSide(Point A, Point B)
        {
            return A.Num * A.Num1 * B.Num * B.Num1 * B.Num1;
        }
        public void Perimeter(Point A) {
            Console.WriteLine($"{A.Name}-Периметр -{(A.Num+A.Num1)*2}");
        }

    }
}
