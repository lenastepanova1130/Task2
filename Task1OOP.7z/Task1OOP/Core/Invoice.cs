﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Invoice
    {
        private int _account;

        public int Account
        {
            get { return _account; }
            set { _account = value; }
        }

        private string _customer;

        public string Customer
        {

            get { return _customer; }
            set { _customer = value; }
        }

        private string _provider;

        public string Provider
        {
            get { return _provider; }
            set { _provider = value; }
        }

        private string _article;

        public string Article
        {
            get { return _article; }
            set { _article = value; }
        }

        private int _quantity;

        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; }
        }

        private double _sumndc;

        public double Sumndc
        {
            get { return _sumndc; }
            set { _sumndc = value; }
        }


        private double _stav;

        public double Stav
        {
            get { return _stav; }
            set { _stav = value; }
        }

       

        public Invoice(double stav)
        {
            Stav = stav;
        }

        
        
    }
}
