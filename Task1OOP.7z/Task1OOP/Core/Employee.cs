﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Employee
    {
		private string _surname;

		public string Surname
		{
			get { return _surname; }
			set { _surname = value; }
		}

		private string _name;

		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}

        public Employee(string surname, string name)
		{
			Surname = surname;
		    Name = name;
		}

		

		private string _dol;

		public string Dol
		{
			get { return _dol; }
			set { _dol = value; }
		}

		private double _oclad;

		public double Oclad
		{
			get { return _oclad; }
			set { _oclad = value; }
		}

		private double _nalog;

		public double Nalog
		{
			get { return _nalog; }
			set { _nalog = value; }
		}

        private double _doloclad;

        public double Doloclad
        {
            get { return _doloclad; }
            set { _doloclad = value; }
        }

        private double _rabd;

        public double Rabd
        {
            get { return _rabd; }
            set { _rabd = value; }
        }

        private double _fizrabd;

        public double Fizrabd
        {
            get { return _fizrabd; }
            set { _fizrabd = value; }
        }
    }
}
