﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1OOP.Core
{
    public class Author
    {
        public Author(string aut)
        {
            Aut = aut;
        }

        private string _author;

		public string Aut
		{
			get { return _author; }
			set { _author = value; }
		}

        public void Show()
        {
           Console.ForegroundColor = ConsoleColor.Green; 
            Console.WriteLine($"Автор -{Aut}");
        }
    }
}
